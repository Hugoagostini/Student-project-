import http.server
import socketserver
import sqlite3
import json

from urllib.parse import urlparse, parse_qs, unquote



class RequestHandler(http.server.SimpleHTTPRequestHandler):

  static_dir = '/client' # déclaration du dossier client


  def do_GET(self):
    self.init_params() # récupération des paramètres
    
    if self.path_info[0] == "location":
      self.send_locations() #/location permet en réalité d'accéder aux informations du pays
      
    else: # sinon on renvoit un document statique
      self.send_static()


  def do_HEAD(self):
    self.send_static()


  def do_POST(self):
    self.init_params()
    
    if self.path_info[0] == "service": # requête générique
      self.send_html(('<p>Path info : <code>{}</code></p><p>Chaîne de requête : <code>{}</code></p>' \
          + '<p>Corps :</p><pre>{}</pre>').format('/'.join(self.path_info),self.query_string,self.body));

    else:
      self.send_error(405)


  def send_static(self): # envoi du document statique

    # insertion d'un répertoire préfixe
    self.path = self.static_dir + self.path

    # appel à la méthode parent
    # à partir du verbe HTTP (GET ou HEAD)
    if (self.command=='HEAD'):
        http.server.SimpleHTTPRequestHandler.do_HEAD(self)
    else:
        http.server.SimpleHTTPRequestHandler.do_GET(self)
        

  def init_params(self): # analyse de l'adresse
    info = urlparse(self.path)
    self.path_info = [unquote(v) for v in info.path.split('/')[1:]]
    self.query_string = info.query
    self.params = parse_qs(info.query)

    # récupération du corps
    length = self.headers.get('Content-Length')
    ctype = self.headers.get('Content-Type')
    if length:
      self.body = str(self.rfile.read(int(length)),'utf-8')
      if ctype == 'application/x-www-form-urlencoded' : 
        self.params = parse_qs(self.body)
    else:
      self.body = ''
   
    # traces
    print('path_info =',self.path_info)
    print('body =',length,ctype,self.body)
    print('params =', self.params)
    
  # méthode d'envoi
  def send(self,body,headers=[]):

    # encodage de la chaine de caractère
    encoded = bytes(body, 'UTF-8')

    # envoi de la ligne statut
    self.send_response(200)

    [self.send_header(*t) for t in headers]
    self.send_header('Content-Length',int(len(encoded)))
    self.end_headers()

    # envoi de la réponse
    self.wfile.write(encoded)

  
  def send_locations(self):
    #connexion à la base de donnée
    conn = sqlite3.connect('pays_test3.sqlite')
    
    # accès au résultat des requêtes sous forme d'un dictionnaire
    conn.row_factory = sqlite3.Row 
    c = conn.cursor() # création d'un curseur
    
    # récupération de la liste des pays dans la base
    c.execute("SELECT name, capital, latitude, longitude, flag FROM country")
    r = c.fetchall()

    # construction de la réponse
    data = []
    n = 0
    for a in r:
       n += 1
       data.append({'id':n, 'name':a[0], 'capital':a[1], 'latitude':a[2], 'longitude':a[3], 'flag':a[4]})
    
    self.send_json(data)
    #print(data['flag'])
    #print(data['name'])
    
    #print(data['latitude'])
    
    conn.close()


  # envoi d'un document html
  def send_html(self,content):
     headers = [('Content-Type','text/html;charset=utf-8')]
     html = '<!DOCTYPE html><title>{}</title><meta charset="utf-8">{}' \
         .format(self.path_info[0],content)
     self.send(html,headers)

  # envoi d'un contenu en json
  def send_json(self,data,headers=[]):
    body = bytes(json.dumps(data),'utf-8') # encodage en json et UTF-8
    self.send_response(200)
    self.send_header('Content-Type','application/json')
    self.send_header('Content-Length',int(len(body)))
    [self.send_header(*t) for t in headers]
    self.end_headers()
    self.wfile.write(body)


# lancement du serveur
httpd = socketserver.TCPServer(("", 8082), RequestHandler)
httpd.serve_forever()